package com.example.andriod.mynews.internetConnection;

import android.net.Uri;
import android.util.Log;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class InternetConnectionUtils {
    ///now i am going to crete  a LOG tag massage..//
    private static final String LOG_TAG = InternetConnectionUtils.class.getSimpleName();

    /*
    now i  am going to have the url of the json
     */
    private static final String WEB_BASE_URL =
            "http://newsapi.org/v2/everything";


    /*
    now i am goign to have the key of the uri..
     */
    private static final String PARAM_KEY_QUERY = "q";
    private static final String PARAM_KEY_SORT_BY = "sortBy";
    private static final String PARAM_API_WEB_URI_KEY = "apiKey";

    /*
    nwo i need the key value..
     */
    private static final String sortBy = "publishedAt";
    private static final String apiKey = "6726a5e0691b4a198f69c33d332ac2fe";




    /**
     * now i ma going to parse the url..
     * @param localKeyQuery
     * @ return newUrl
     */
    public static URL buildURL (String localKeyQuery){
        //now i am going to use the uri that will help me to parese the url..//

        Uri buildUri = Uri.parse(WEB_BASE_URL).buildUpon()
                .appendQueryParameter(PARAM_KEY_QUERY,localKeyQuery)
                .appendQueryParameter(PARAM_KEY_SORT_BY,sortBy)
                .appendQueryParameter(PARAM_API_WEB_URI_KEY,apiKey)
                .build();
        //now i am goign to declare the URL object..//
        URL newURL = null;
        try{
            newURL = new URL(buildUri.toString());
        } catch (MalformedURLException e) {
            e.printStackTrace();
            Log.e(LOG_TAG,"cant build the uri:"+newURL);
        }
        Log.e(LOG_TAG,"the URL"+newURL);
        return newURL;
    }
    public static String URLHTTPrequestResponse(URL url) throws IOException {
        HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
        urlConnection.setRequestMethod("GET");
        urlConnection.connect();
        try {
            InputStream in = urlConnection.getInputStream();

            Scanner scanner = new Scanner(in);
            scanner.useDelimiter("\\A");

            boolean hasInput = scanner.hasNext();
            if (hasInput) {
                return scanner.next();
            } else {
                return null;
            }
        } finally {
            urlConnection.disconnect();
        }
    }
}
