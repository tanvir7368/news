package com.example.andriod.mynews;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;

import com.example.andriod.mynews.internetConnection.InternetConnectionUtils;

import java.io.IOException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    ///declaring the edit text view...///
    private EditText mEdiTextView;
    private TextView mTextViewDisplay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //now i am goign to initilize the view..//
        mEdiTextView = (EditText) findViewById(R.id.key_search_edit_view);
        mTextViewDisplay = (TextView) findViewById(R.id.json_view);
    }
    private void makeSearchQuery(){
        String keyToSearch= mEdiTextView.getText().toString();
        ///now i am geting the url..//
        URL searchURL = InternetConnectionUtils.buildURL(keyToSearch);
        ///now i am goign to call the assynsctask..//
        new GithubQueryTask().execute(searchURL);
    }
    public class  GithubQueryTask extends AsyncTask<URL,Void,String>{
        @Override
        protected String doInBackground(URL... urls) {
            ///creating the URl and see the position of the url../
            URL searchURL = urls[0];
            String githubSearchQuery = null;
            try{
                githubSearchQuery = InternetConnectionUtils.URLHTTPrequestResponse(searchURL);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return githubSearchQuery;
        }

        @Override
        protected void onPostExecute(String githubSearchResults) {
            if (githubSearchResults != null || !githubSearchResults.equals("")){
                mTextViewDisplay.setText(githubSearchResults);
            }else {
                mTextViewDisplay.setText("NOthing to show");
            }
        }
    }

    /**
     * now i am goign to create the menu
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //now i am goign to inflate the menu..//
        getMenuInflater().inflate(R.menu.searching_preference_view,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.search_bar){
            makeSearchQuery();
        }
        return super.onOptionsItemSelected(item);
    }
}